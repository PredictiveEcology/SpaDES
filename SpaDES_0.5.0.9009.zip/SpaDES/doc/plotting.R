
## ----load_files, eval=TRUE, echo=TRUE, message=FALSE, fig.height=2-------
#  Make list of maps from package database to load, and what functions to use to load them
library(SpaDES)
fileList <-
    data.frame(files =
     dir(file.path(find.package("SpaDES",
                                lib.loc=getOption("devtools.path"),
                                quiet=FALSE),
                  "maps"),
        full.names=TRUE, pattern= "tif"),
     functions="rasterToMemory",
     .stackName="landscape",
     packages="SpaDES",
     stringsAsFactors=FALSE)

# Load files to memory (using rasterToMemory) and stack them (because .stackName is provided above)
loadFiles(fileList=fileList)
# extract a single one of these rasters
DEM <- landscape$DEM


## ----first_plot, eval=TRUE, echo=TRUE, fig.height=2----------------------
Plot(landscape, new=TRUE)
# make a SpatialPoints object
caribou <- SpatialPoints(coords=cbind(x=runif(1e2,-50,50),y=runif(1e2,-50,50)))
Plot(caribou)
Plot(caribou, addTo="landscape.habitatQuality")

# SpatialPolygons
Sr1 = Polygon(cbind(c(2,4,4,1,2),c(2,3,5,4,2))*20-50)
Sr2 = Polygon(cbind(c(5,4,2,5),c(2,3,2,2))*20-50)

Srs1 = Polygons(list(Sr1), "s1")
Srs2 = Polygons(list(Sr2), "s2")
SpP = SpatialPolygons(list(Srs1,Srs2), 1:2)
Plot(SpP)
Plot(SpP, addTo="landscape.habitatQuality", gp=gpar(lwd=2))



## ----set_colors, eval=TRUE, echo=TRUE, fig.height=2----------------------
# can change color palette
Plot(landscape, new=TRUE)
library(RColorBrewer)
setColors(landscape, n=50) <-
              list(DEM=topo.colors(50),
                   forestCover=colorRampPalette(c("blue","orange","purple","red"))(50),
                   forestAge=brewer.pal("Blues", n=8),
                   habitatQuality=brewer.pal(9, "Spectral"),
                   percentPine=brewer.pal("GnBu", n=8))
Plot(landscape[[2:3]])


## ----mixing_layer_types, eval=TRUE, echo=TRUE, fig.height=2--------------
Plot(landscape, caribou, DEM, SpP, new=TRUE, axes=TRUE, gp=gpar(cex=0.5))


## ----visualSqueeze, eval=TRUE, echo=TRUE, fig.height=2, dpi=900----------
# x axis gets cut off in pdf and html
Plot(DEM, new=TRUE)
Plot(DEM, visualSqueeze=0.6, new=TRUE)


## ----simple_add, eval=TRUE, echo=TRUE, fig.height=3----------------------
Plot(landscape, new=TRUE)
# can add a new plot to the plotting window
Plot(caribou, new=FALSE, axes=FALSE)


## ----add_with_rearrangement, eval=TRUE, echo=TRUE, fig.height=2----------
Plot(landscape[[1:4]], new=TRUE)
# can add a new plot to the plotting window
Plot(caribou, new=FALSE, axes=FALSE)


## ----add_with_same_name, eval=TRUE, echo=TRUE, fig.height=2--------------
Plot(landscape[[1:3]], new=TRUE)
landscape$forestAge[] = ((landscape$forestAge[] + 10) %% 100)
landscape$forestCover[] = ((landscape$forestCover[] +10) %% 30)
# can add a new plot to the plotting window
Plot(landscape[[2:3]], new=FALSE)
# note that zeros are treated as no color by default. If this is not the correct behavior, use
#  zero.color=NULL
Plot(landscape[[2:3]], new=FALSE, zero.color=NULL)



## ----speedup, eval=TRUE, echo=TRUE, fig.height=2-------------------------
system.time(Plot(landscape, caribou, DEM, new=TRUE))
system.time(Plot(landscape, caribou, DEM, speedup=10, new=TRUE))
# can add a new plot to the plotting window


## ----add, eval=TRUE, echo=TRUE, fig.height=2-----------------------------
Plot(landscape, new=TRUE)
Plot(caribou, addTo="landscape.forestAge", size=2, axes=F)


## ----, echo=TRUE, eval=FALSE---------------------------------------------
## # simple:
## dev(4)
## 
## # better:
## #Plot all maps on a new plot windows - Do not use RStudio window
## if(is.null(dev.list())) {
##    dev(2)
## } else {
##  if(any(names(dev.list())=="RStudioGD")) {
##    dev(which(names(dev.list())=="RStudioGD")+3)
##  } else {
##    dev(max(dev.list()))
##  }
## }


## ----clickValues, eval=FALSE, echo=TRUE----------------------------------
## Plot(landscape, new=TRUE)
## clickValues(3) #click at three locations on the Plot device


## ----clickExtent, eval=FALSE, echo=TRUE----------------------------------
## Plot(landscape, new=TRUE)
## clickExtent() #click at two locations on the Plot device

