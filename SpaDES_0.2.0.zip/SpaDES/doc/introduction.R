### R code from vignette source 'introduction.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: setup-workspace
###################################################
## for now only while testing, etc.
OS <- tolower(Sys.info()["sysname"])
hostname <- gsub(Sys.info()["nodename"],pattern="W-VIC-",replace="")

if (OS=="windows") {
    if(pmatch("A105200", hostname, nomatch=FALSE)) {
        path <- "c:/Eliot/GitHub"
    } else {
        path <- "~/GitHub"
    }
} else {
    path <- "~/Documents/GitHub"
}
#devtools::dev_mode(TRUE)
devtools::load_all(file.path(path, "SpaDES")) # for development/testing

## 
#library(SpaDES)


###################################################
### code chunk number 2: habitat-map
###################################################
nx = 1e3
ny = 1e3
habitat = raster(nrows=ny, ncols=nx, xmn=-nx/2, xmx=nx/2, ymn =-ny/2, ymx=ny/2)
habitat = round(GaussMap(habitat, speedup=10), 1)
names(habitat) = "habitatQuality"

simPlot(habitat)


###################################################
### code chunk number 3: mobile-point-agent
###################################################
N <- 10 # number of agents

# caribou data vectors
IDs <- c("Alice", "Bob", "Clark", "Daisy", "Eric",
         "Franz", "Gabby", "Hayley", "Igor", "Jane")
sex <- c("female", "male", "male", "female", "male",
         "male", "female", "female", "male", "female")
age <- round(rnorm(N, mean=8, sd=3))

# create the caribou agent object
caribou <- SpatialPointsDataFrame(coords=cbind(x=rnorm(N, mean=0, sd=100),
                                               y=rnorm(N, mean=0, sd=100)),
                                  data=data.frame(sex=sex, age=age))
row.names(caribou) <- IDs # alternatively, add IDs as column in data.frame above

head(caribou)
coordinates(caribou)

## conventional plotting method
#plot(habitat)
#plot(caribou, add=TRUE)

# improved plotting using simPlot
simPlot(habitat)
simPlot(caribou, ext=extent(habitat), on.which.to.plot=1, add=TRUE, pch=19,
        gp=gpar(cex=0.1), delete.previous=FALSE)


