### R code from vignette source 'plotting.Rnw'
### Encoding: ASCII

###################################################
### code chunk number 1: habitat-map (eval = FALSE)
###################################################
## library(raster)
## library(RColorBrewer)
## 
## # Give dimensions of dummy raster
## nx <- 1e2
## ny <- 1e2
## template <- raster(nrows=ny, ncols=nx, xmn=-nx/2, xmx=nx/2, ymn =-ny/2, ymx=ny/2)
## 
## # Make dummy maps for testing of models:
## # - digital elevation model (DEM)
## # - forest age
## # - forset cover
## # - percent pine
## DEM <- round(GaussMap(template, scale=300, var=0.03, speedup=1), 1)*1000
## forestAge <- round(GaussMap(template, scale=10, var=0.1, speedup=1), 1)*20
## forestCover <- round(GaussMap(template, scale=50, var=1, speedup=1),2)*10
## percentPine <- round(GaussMap(template, scale=50, var=1, speedup=1),1)
## 
## # Scale them as needed
## forestAge <- forestAge/maxValue(forestAge)*100
## percentPine <- percentPine/maxValue(percentPine)*100
## 
## # Make layers that are derived from other layers
## habitatQuality <- (DEM+10 + (forestCover+5)*10)/100
## habitatQuality <- habitatQuality/maxValue(habitatQuality)
## 
## # Stack them into a single stack for plotting
## habitat <- stack(list(DEM, forestAge, forestCover, habitatQuality, percentPine))
## 
## names(habitat) <- c("DEM", "forestAge", "forestCover", "habitatQuality", "percentPine")
## 
## cols <- list(
##   transparent.greys <- c("#00000000", paste(brewer.pal(8,"Greys"), "66", sep="")[8:1]),
##   grey <- brewer.pal(9,"Greys"),
##   spectral <- brewer.pal(8,"Spectral"),
##   terrain <- rev(terrain.colors(100)),
##   heat <- heat.colors(10),
##   topo <- topo.colors(10)
## )
## 
## name(habitat) <- "habitat"
## Plot(habitat)


###################################################
### code chunk number 2: mobile-point-agent
###################################################
N <- 1e1 # number of agents

# caribou data vectors
IDs <- c("Alice", "Bob", "Clark", "Daisy", "Eric",
         "Franz", "Gabby", "Hayley", "Igor", "Jane")
sex <- c("female", "male", "male", "female", "male",
         "male", "female", "female", "male", "female")
age <- round(rnorm(N, mean=8, sd=3))
prevX <- runif(N, xmin(habitat)+(ncol(habitat)*0.2), xmax(habitat)-(ncol(habitat)*0.2))
prevY <- runif(N, ymin(habitat)+(nrow(habitat)*0.2), ymax(habitat)-(nrow(habitat)*0.2))

# create the caribou agent object
caribou <- SpatialPointsDataFrame(coords=cbind(x=rnorm(N, prevX, ncol(habitat)/20),
                                               y=rnorm(N, prevY, ncol(habitat)/20)),
                                  data=data.frame(prevX, prevY, sex, age))
row.names(caribou) <- IDs # alternatively, add IDs as column in data.frame above

heading(SpatialPoints(cbind(x=prevX,y=prevY)),caribou)
coordinates(caribou)

## conventional plotting method - agents don't plot properly when it is a raster stack
#plot(habitat)
#plot(caribou, add=TRUE)

# convenient plotting using Plot
Plot(habitat)
Plot(caribou, addTo="habitatQuality", pch=19, size=1)
drawArrows(from=SpatialPointsNamed(cbind(x=prevX, y=prevY)),
           to=caribou,
           addTo="DEM")


