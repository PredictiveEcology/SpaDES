# Spatial Discrete Event Simulation (SpaDES)

R package for building spatially explicit discrete event simulation
models.

## Installation

### to install `SpaDES` from github you will need the `devtools` package:

    install.packages("devtools")
    library(devtools)
    install_github("SpaDES", username="achubaty")
