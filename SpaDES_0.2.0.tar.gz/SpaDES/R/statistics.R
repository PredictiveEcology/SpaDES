###################################################################
###
###     Methods for the ABM simulation: "observer" module:
###
###     Statistics gathering & reporting (via event calls);
###         - stats to file or to screen (toggle)
###     
###################################################################