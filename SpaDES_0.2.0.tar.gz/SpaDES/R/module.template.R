# autogenerate a skeleton for a new module
module.skeleton = function(name, path) {
    path <- check.path(path) # defined in simulation.R

###
### INSERT TEMPLATE CODE HERE
###

    # print each module component into a file "path/name"
    filename <- paste(path, name, sep="")
#    sprintf()
}