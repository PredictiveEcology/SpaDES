###################################################################
###
###     Methods for the ABM simulation: "observer" module:
###
###     Simulation experiment builder.
###     
###################################################################