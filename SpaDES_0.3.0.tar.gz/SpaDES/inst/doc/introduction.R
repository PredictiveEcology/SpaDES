### R code from vignette source 'introduction.Rnw'
### Encoding: ASCII

###################################################
### code chunk number 1: SpaDES-demo (eval = FALSE)
###################################################
## # demo 1: randomLandscapes, fireSpread, caribouMovement
## demo("spades-simulation", package="SpaDES")
## 
## # demo 2: forestSuccession, forestAge
## #demo("spades-succession", package="SpaDES") # not yet implemented


###################################################
### code chunk number 2: using-SpaDES (eval = FALSE)
###################################################
## library(SpaDES)
## 
## times <- list(start=0,stop=100.02)
## parameters <- list(.globals=list(mapName="landscape"),
##                   .progress=list(NA),
##                   randomLandscapes = list(nx=1e2, ny=1e2,
##                                           .plotInitialTime = 0, .plotInterval=1e3,
##                                           startTime=0),
##                   fireSpread=list(nFires = 1e1, spreadprob=0.225,
##                                   persistprob=0, its=1e6,
##                                   .plotInitialTime = 0.1, .plotInterval=10,
##                                   returnInterval = 10, startTime=0),
##                   caribouMovement=list(N=1e2,
##                                        .plotInitialTime = 1.01, .plotInterval=1,
##                                        moveInterval=1, startTime=0))
## modules <- list("randomLandscapes", "fireSpread", "caribouMovement")
## path <- system.file("sampleModules", package="SpaDES")
## 
## mySim <- simInit(times=times, params=parameters, modules=modules, path=path)
## 
## doSim(mySim)


###################################################
### code chunk number 3: fire (eval = FALSE)
###################################################
## nFires <- 10 # number of agents
## landscape[["Fires"]] <-
##   spread(landscape[[1]],
##          loci=as.integer(sample(1:ncell(landscape), nFires)),
##          spreadProb=landscape[["percentPine"]]/(maxValue(landscape[["percentPine"]])*5)+0.1,
##          persistance=0,
##          mapFireID=TRUE,
##          mask=NULL,
##          maxSize=1e8,
##          directions=8,
##          iterations=1e6,
##          plot.it=FALSE,
##          mapID=TRUE)
## 
## simPlot(landscape[["Fires"]])


###################################################
### code chunk number 4: fire-overlaid (eval = FALSE)
###################################################
## # Show the burning more strongly over abundant pine
## simPlot(landscape[["percentPine"]], col=.cols[[3]])
## simPlot(landscape[["Fires"]], add=TRUE, delete.previous=FALSE, col=.cols[[1]])


###################################################
### code chunk number 5: fire-impacts (eval = FALSE)
###################################################
## # Show the burning more strongly over abundant pine
## fire <- reclassify(landscape[["Fires"]],rcl= cbind(0:1,c(0,ncell(landscape)),0:1))
## pine <- reclassify(landscape[["percentPine"]],rcl= cbind(0:9*10, 1:10*10, 0:9))
## PineByFire <- crosstab(fire, pine, long=TRUE)
## colnames(PineByFire) <- c("fire", "pine", "freq")
## PineByFire$pine <- as.numeric(as.character(PineByFire$pine))
## summary(glm(freq ~ fire*pine, data=PineByFire, family="poisson"))


###################################################
### code chunk number 6: fire-impacts-maps (eval = FALSE)
###################################################
## landscape[["forestAge"]][landscape[["Fires"]]>0] <- 0
## landscape[["forestCover"]][landscape[["Fires"]]>0] <- 0
## landscape[["habitatQuality"]][landscape[["Fires"]]>0] <- 0.1
## landscape[["percentPine"]][landscape[["Fires"]]>0] <- 0
## simPlot(landscape, col=.cols[c(2:5,3,1)])


###################################################
### code chunk number 7: agent-crw-trajectory (eval = FALSE)
###################################################
## simPlot(landscape[["habitatQuality"]], col=.cols[[3]])
## 
## for (i in 1:10) {
##   #crop any caribou that went off maps
##   caribou <<- crop(caribou,landscape)
##   drawArrows(from=SpatialPoints(cbind(x=caribou$prevX, y=caribou$prevY)),
##              to=caribou,length=0.04,
##              on.which.to.plot=1)
## 
##   # find out what pixels the individuals are on now
##   ex <- landscape[["habitatQuality"]][caribou]
## 
##   #step length is a function of current cell's landscape quality
##   sl <- 0.25/ex
## 
##   ln <- rlnorm(length(ex), sl, 0.02) # log normal step length
##   sd <- 30 # could be specified globally in params
## 
##   caribou <<- crw(caribou, stepLength=ln, stddev=sd, lonlat=FALSE)
## }


