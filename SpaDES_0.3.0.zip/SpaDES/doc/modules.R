### R code from vignette source 'modules.Rnw'
### Encoding: ASCII

###################################################
### code chunk number 1: checkpoints
###################################################
library("SpaDES")

# initialize a new simulation, setting the checkpoint interval and checkpoint filename.
times <- list(start=0,stop=100.02)
outputPath=file.path("~", "tmp", "simOutputs")
parameters <- list(.globals=list(mapName="landscape", .outputPath=outputPath),
                   .checkpoint=list(interval=10, file="chkpnt.RData"),
                   randomLandscapes=list(nx=1e2, ny=1e2,
                     .plotInitialTime=0, .plotInterval=1e3))
modules <- list("randomLandscapes")
path <- system.file("sampleModules", package="SpaDES")

mySim <- simInit(times=times, params=parameters, modules=modules, path=path)

spades(mySim)

# retrieve the checkpoint params from the simulation object
simParams(mySim)$.checkpoint
simParams(mySim)$.checkpoint$interval
simParams(mySim)$.checkpoint$file


###################################################
### code chunk number 2: progress (eval = FALSE)
###################################################
## # initialize a new simulation, setting the progress parameters
## mySim <- simInit(times=list(start=0.0, stop=100),
##                  params=list(.progress=list(.graphical=FALSE, .progressInterval=10)),
##                  modules=list("randomLandscapes"),
##                  path="SAMPLE"
## )
## 
## # retrieve the checkpoint params from the simulation object
## simParams(mySim)$.progress
## simParams(mySim)$.progress$.graphical
## simParams(mySim)$.progress$.progressInterval


###################################################
### code chunk number 3: load-save (eval = FALSE)
###################################################
## # initialize a new simulation, setting the load and save parameters
## mySim <- simInit(times=list(start=0.0, stop=100),
##                  params=list(
##                    .loadFileList=data.frame(files=dir(pattern="tif"), stringsAsFactors=FALSE),
##                    randomLandscapes=list(nx=1e2, ny=1e2,
##                                 .saveObjects=c("habitat"),
##                                 .savePath=file.path("output", "randomLandscapes"),
##                                 .saveInitialTime=0,
##                                 .saveInterval=10),
##                    ),
##                  modules=list("randomLandscapes"),
##                  path="SAMPLE"
## )
## 
## # retrieve the load and save params from the simulation object
## simFileList(mySim)
## simParams(mySim)$randomLandscapes$.saveObjects
## simParams(mySim)$randomLandscapes$.savePath
## simParams(mySim)$randomLandscapes$.saveInitialTime
## simParams(mySim)$randomLandscapes$.saveInterval
## 
## # schedule a recurring save event [WITHIN A MODULE]
## nextSave <- simCurrentTime(sim) + simParams(sim)$randomLandscapes$.saveInterval
## sim <- scheduleEvent(sim, nextSave, "randomLandscapes", "save")


###################################################
### code chunk number 4: create-new-module (eval = FALSE)
###################################################
## # create a new module called "randomLandscape" in the "custom-modules" subdirectory
## # and open the resulting file immediately for editing.
## newModule(name="randomLandscapes", path="custom-modules", open=TRUE)


###################################################
### code chunk number 5: plotting (eval = FALSE)
###################################################
## # initialize a new simulation, setting the load and save parameters
## mySim <- simInit(times=list(start=0.0, stop=100),
##                  params=list(
##                    randomLandscapes=list(nx=1e2, ny=1e2,
##                                 .plotInitialTime=0, .plotInterval=1)
##                    ),
##                  modules=list("randomLandscapes"),
##                  path="SAMPLE"
## )
## 
## # retrieve the plotting params from the simulation object
## simParams(mySim)$randomLandscapes$.plotInitialTime
## simParams(mySim)$randomLandscapes$.plotInterval
## 
## # schedule a recurring save event [WITHIN A MODULE]
## nextPlot <- simCurrentTime(sim) + simParams(sim)$randomLandscapes$.plotInterval
## sim <- scheduleEvent(sim, nextPlot, "randomLandscapes", "save")


###################################################
### code chunk number 6: randomLandscapes
###################################################
source(file.path(system.file("sampleModules", package="SpaDES"), "randomLandscapes.R"), echo=TRUE, max.deparse.length=10000)


###################################################
### code chunk number 7: fireSpread
###################################################
source(file.path(system.file("sampleModules", package="SpaDES"), "fireSpread.R"), echo=TRUE, max.deparse.length=10000)


###################################################
### code chunk number 8: caribouMovement
###################################################
source(file.path(system.file("sampleModules", package="SpaDES"), "caribouMovement.R"), echo=TRUE, max.deparse.length=10000)


