#' @export
.spadesEnv <- new.env(parent = emptyenv())
